package ru.otus.spring.libraryacl;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibrarySpringAclApplicationTests {

	@Test
	void contextLoads() {
	}

}
