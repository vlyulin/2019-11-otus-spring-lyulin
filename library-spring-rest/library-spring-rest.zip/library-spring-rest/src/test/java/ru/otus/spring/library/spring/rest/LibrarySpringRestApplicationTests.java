package ru.otus.spring.library.spring.rest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibrarySpringRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
