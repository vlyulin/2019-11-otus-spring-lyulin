package ru.otus.spring.library.spring.rest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibrarySpringRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(LibrarySpringRestApplication.class, args);
	}

}
